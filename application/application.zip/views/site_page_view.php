<div class="container-fluid allUsers">
    <br />
        <div class="col-lg-12 col-md-12 col-sm-12" style="margin-top: 100px;">
            <div class="col-lg-12 col-md-12 col-sm-12 s_block" style="padding:10px !important;">
                <h4 class="pt-10"><?php echo $page[0]->title; ?></h4>
                <?php echo $page[0]->content; ?>
            </div>
        </div>
</div>